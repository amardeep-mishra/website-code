<html>
<body>
<?php
$n = $_POST['email'];
$r = $_POST['number'];
$a = $_POST['name'];
$m = $_POST['password'];

$con = mysql_connect("localhost:3306","root","");


if (!$con)
{
	
	die("Could not connect: " . mysql_error());
}
mysql_select_db("medi", $con);

mysql_query("INSERT INTO hosp VALUES ('$n', '$r','$a','$m')") or die(mysql_error());
echo "The data is succesfully inserted!!!";

mysql_close($con);

?> 

<br /><a href="index.html">Go Back</a>
</body>
</html>