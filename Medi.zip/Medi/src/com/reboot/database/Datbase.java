package com.reboot.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Datbase {
private static Connection con;
private static Properties property;
public static Connection getCon() {
	return con;
}
public static void setCon(Connection con) {
	Datbase.con = con;
}
public static Properties getProperty() {
	return property;
}
public static void setProperty(Properties property) {
	Datbase.property = property;
}
public static Connection getConnection()
{
	try
	{
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/medi","root","");
	}
	catch(ClassNotFoundException e)
	{
		System.out.println("class not found");
	}
	catch(SQLException se)
	{
		System.out.println("Driver Not Creteaed");
	}
	return con;
}
}
