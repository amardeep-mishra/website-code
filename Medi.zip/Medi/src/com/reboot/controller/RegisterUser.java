package com.reboot.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.reboot.bean.User;
import com.reboot.database.Datbase;

public class RegisterUser extends HttpServlet {

protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
User u=new  User();
System.out.println(req.getParameter("Email"));
System.out.println(req.getParameter("Uname"));
System.out.println(req.getParameter("Password"));
System.out.println(req.getParameter("UserType"));

String Email=req.getParameter("Email");
String Username=req.getParameter("Uname");
String Password=req.getParameter("Password");
String UserType=req.getParameter("UserType");


u.setEmail(Email);
u.setPassword(Password);
u.setUsertype(UserType);
u.setUname(Username);

//Datbase d=new Datbase();
//d.getConnection();
Connection con;



con=Datbase.getConnection();
 System.out.println("HIIIIIIII");
 Statement s = null;
 ResultSet r;
 try {
	s=con.createStatement();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
// String sql "insert into hosp values(\"abc@gmail.com\",\"abc\",\"xyz\",\"doc\")
String sql="INSERT INTO hosp VALUES  (\""+u.getEmail()+"\",\""+u.getUname()+"\",\""+u.getPassword()+"\",\""+u.getUsertype()+"\")";
try {
	s.executeUpdate(sql);
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}

}
